package cn;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyFrame myFrame = new MyFrame();

	}

}
